# SalesMasterApp (Android)

Minimal multi-screen starter with an AI Chat screen that calls OpenAI.
- Main screen with buttons
- Chat screen using OkHttp to call `v1/chat/completions`
- API key is injected at build-time by GitHub Actions (secret `OPENAI_API_KEY`).

## Build locally (Android Studio)
- Open the project folder.
- Add `app/src/main/res/values/secrets.xml` with your key, or rely on CI to inject it.

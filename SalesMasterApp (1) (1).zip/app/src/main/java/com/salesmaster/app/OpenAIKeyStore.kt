package com.salesmaster.app

import android.content.Context

object OpenAIKeyStore {
    private const val PREF = "salesmaster_prefs"
    private const val KEY = "openai_key"
    fun saveKey(context: Context, value: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, value).apply()
    }
    fun getKey(context: Context): String? {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null)
    }
}
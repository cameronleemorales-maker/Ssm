package com.salesmaster.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class ChatActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        val input = findViewById<EditText>(R.id.inputMessage)
        val btn = findViewById<Button>(R.id.btnSend)
        val output = findViewById<TextView>(R.id.txtResponse)

        btn.setOnClickListener {
            val prompt = input.text.toString().trim()
            if (prompt.isEmpty()) return@setOnClickListener
            output.text = "Thinking…"

            askOpenAI(prompt) { result ->
                runOnUiThread { output.text = result }
            }
        }
    }

    private fun askOpenAI(userPrompt: String, callback: (String) -> Unit) {
        val apiKey = getString(R.string.openai_api_key)
        if (apiKey.isBlank() || apiKey == "SET_IN_GITHUB_SECRETS") {
            callback("OpenAI API key is missing. Add it as a GitHub secret OPENAI_API_KEY.")
            return
        }

        val json = JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("messages", listOf(
                JSONObject().apply {
                    put("role", "system")
                    put("content", "You are SalesMaster AI. Provide concise, friendly rebuttals and a short example sentence the salesperson can say.")
                },
                JSONObject().apply {
                    put("role", "user")
                    put("content", userPrompt)
                }
            ))
        }

        val body = RequestBody.create("application/json; charset=utf-8".toMediaType(), json.toString())
        val req = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(body)
            .build()

        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("Network error: " + e.message)
            }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        callback("API error: HTTP " + it.code)
                        return
                    }
                    val txt = it.body?.string() ?: "{}"
                    try {
                        val root = JSONObject(txt)
                        val content = root.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                        callback(content.trim())
                    } catch (ex: Exception) {
                        callback("Parse error")
                    }
                }
            }
        })
    }
}

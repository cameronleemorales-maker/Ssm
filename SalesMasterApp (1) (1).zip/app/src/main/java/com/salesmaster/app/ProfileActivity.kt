package com.salesmaster.app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.salesmaster.app.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Show current key masked
        val current = OpenAIKeyStore.getKey(this)
        binding.apiHint.text = if (current.isNullOrBlank()) {
            "No API key set. Enter one to enable live AI responses."
        } else {
            "API key set: ****" + current.takeLast(6)
        }
    }
}
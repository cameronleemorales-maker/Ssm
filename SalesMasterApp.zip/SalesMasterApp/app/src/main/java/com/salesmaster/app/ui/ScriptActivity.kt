package com.salesmaster.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.salesmaster.app.databinding.ActivityScriptBinding

class ScriptActivity: AppCompatActivity() {
    private lateinit var binding: ActivityScriptBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScriptBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.tvTitle.text = "Script Library"
    }
}